<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Dashboard</title>
    <?php echo $__env->make('dashboard.partials.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <?php echo $__env->yieldContent('modal'); ?>
    <div class="bmd-layout-container bmd-drawer-f-l">
        <header class="bmd-layout-header">
            <div class="navbar navbar-danger bg-danger bg-faded">
                <button class="navbar-toggler" type="button" data-toggle="drawer" data-target="#dw-s1">
                    <span class="sr-only">Toggle drawer</span>
                    <i class="material-icons">menu</i>
                </button>
                
            </div>
        </header>
        <div id="dw-s1" class="bmd-layout-drawer bg-danger  bg-faded">
            <header>
                <a class="navbar-brand text-black font-weight-bold">Subba Blood Bank</a>
            </header>
            <ul class="list-group">
                <a href="/dashboard" class="list-group-item text-white">Dashboard</a>
                <a href="/events" class="list-group-item text-white">Events</a>
                <a href="/blood-requests" class="list-group-item text-white">Blood Requests</a>
                <a href="/recipients" class="list-group-item text-white">Recipients</a>
                <a href="/users" class="list-group-item text-white">Users</a>
                <a href="/donors" class="list-group-item text-white">Donors</a>
                <a href="/profile" class="list-group-item text-white">Profile</a>
                <a href="/logout" class="list-group-item text-white">Logout</a>
            </ul>
        </div>
        <main class="bmd-layout-content">
            <div class="container-fluid mt-2">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
    </div>

    <?php echo $__env->make('dashboard.partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH D:\work\WTN\FINAL_YEAR_PROJECTS\BloodBankManagementSystem\BloodBankManagementSystem\resources\views/dashboard/layouts/base.blade.php ENDPATH**/ ?>