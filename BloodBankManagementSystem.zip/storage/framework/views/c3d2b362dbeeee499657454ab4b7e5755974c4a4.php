<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb ">
    <ol class="breadcrumb bg-transparent">
        <li class="breadcrumb-item "><a href="/dashboard" class="text-dark">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Donors</li>
    </ol>
</nav>



<div class="card mt-3">
    <div class="card-body">

        <h5 class="card-title">Donors Lists</h5>
        <div>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Image</th>
                        <th scope="col">Name</th>
                        <th scope="col">Gender</th>
                        <th scope="col">Age</th>
                        <th scope="col">Blood Group</th>
                        <th scope="col">Address</th>
                        <th scope="col">Contact</th>
                        <th scope="col">Email</th>
                        <?php if(Auth::user()->type == 'admin'): ?>

                        <th scope="col">Action</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($donors)): ?>
                    <?php $__currentLoopData = $donors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->index + 1); ?></th>
                        <td>
                        <?php if($item['image'] == '-'): ?>
                           <img src="<?php echo e(asset('/images/profile_placeholder.png')); ?>" class="img-fluid " style="max-height: 45px;">
                           <?php else: ?>

                           <img src="<?php echo e(asset('/images/profile/'.$item['image'])); ?>" class="img-fluid " style="max-height: 45px;">
                           <?php endif; ?>
                        </td>

                        <td><?php echo e($item['name']); ?></td>
                        <td><?php echo e($item['gender']); ?></td>
                        <td><?php echo e($item['age']); ?></td>
                        <td><?php echo e($item['blood_group']); ?></td>
                        <td><?php echo e($item['address']); ?></td>
                        <td><?php echo e($item['address']); ?></td>
                        <td><?php echo e($item['contact']); ?></td>
                        <td><?php echo e($item['email']); ?></td>
                        <?php if(Auth::user()->type == 'admin'): ?>

                        <td>
                            <a href="/donors/<?php echo e($item['user_id']); ?>/remove"><i class="material-icons text-danger">delete</i></a>
                        </td>
                        <?php endif; ?>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\WTN\FINAL_YEAR_PROJECTS\BloodBankManagementSystem\BloodBankManagementSystem\resources\views/dashboard/donors/index.blade.php ENDPATH**/ ?>