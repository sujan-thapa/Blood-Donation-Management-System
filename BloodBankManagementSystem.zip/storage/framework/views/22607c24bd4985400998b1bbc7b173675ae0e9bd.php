<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb ">
    <ol class="breadcrumb bg-transparent">
        <li class="breadcrumb-item "><a href="/dashboard" class="text-dark">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Profile</li>
    </ol>
</nav>


<div class="row justify-content-center">
    <div class="col-12 col-md-8">
        <div class="card mt-3 mb-5">
            <div class="card-body">
                <h5 class="card-title text-center">Profile</h5>
                <?php if($profile->image == '-'): ?>
                <img src="<?php echo e(asset('/images/profile_placeholder.png')); ?>" class="img-fluid d-block m-auto"  style="max-height: 150px;" >
                <?php else: ?>

                <img src="<?php echo e(asset('/images/profile/'.$profile->image)); ?>" class="img-fluid d-block m-auto"  style="max-height: 150px;" >
                <?php endif; ?>
                <ul class="list-group">
                    <a class="list-group-item">
                        <div class="bmd-list-group-col">
                            <p class="list-group-item-heading">Name</p>
                            <p class="list-group-item-text"><?php echo e($profile->name); ?></p>
                        </div>
                    </a>
                    <a class="list-group-item">
                        <div class="bmd-list-group-col">
                            <p class="list-group-item-heading">Email</p>
                            <p class="list-group-item-text"><?php echo e($user->email); ?></p>
                        </div>
                    </a>
                    <a class="list-group-item">
                        <div class="bmd-list-group-col">
                            <p class="list-group-item-heading">Contact</p>
                            <p class="list-group-item-text"><?php echo e($profile->contact); ?></p>
                        </div>
                    </a>
                    <a class="list-group-item">
                        <div class="bmd-list-group-col">
                            <p class="list-group-item-heading">Address</p>
                            <p class="list-group-item-text"><?php echo e($profile->address); ?></p>
                        </div>
                    </a>
                </ul>
                <div class="text-center">
                    <a href="/profile/edit" class="btn btn-danger active">Edit Profile</a>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\WTN\FINAL_YEAR_PROJECTS\BloodBankManagementSystem\BloodBankManagementSystem\resources\views/dashboard/profile/index.blade.php ENDPATH**/ ?>