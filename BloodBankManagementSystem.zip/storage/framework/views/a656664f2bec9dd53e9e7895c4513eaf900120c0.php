<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb ">
    <ol class="breadcrumb bg-transparent">
        <li class="breadcrumb-item "><a href="/" class="text-dark">Home</a></li>
        <li class="breadcrumb-item"><a href="/events" class="text-dark">Events</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($event->title); ?></li>
    </ol>
</nav>

<div class="row justify-content-center">
    <div class="col-12 col-md-3">
        <div class="card mt-3 mb-5">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($event->title); ?></h5>
                <p class="cart-text">
                    <?php echo e($event->desc); ?>

                </p>
                <p>
                    <span>
                        Date & Time : <?php echo e($event->date_time); ?>

                    </span>
                    <br>
                    <span>
                        Location : <?php echo e($event->location); ?>

                    </span>
                </p>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-9">
        
        <div class="card mt-3 mb-5">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h5 class="card-title ">Donation Record</h5>
                    <a href="/events/<?php echo e($event->id); ?>/view/add-donation-record" type="button" class="btn btn-dark active" >
                        Add Donation Record
                    </a>
                </div>

                <div class="  mt-3 table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Age</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Address</th>
                                <th scope="col">Contact</th>
                                <th scope="col">Blood Group</th>
                                <th scope="col">Volume (ml)</th>
                                <?php if(Auth::user()->type == 'admin'): ?>

                                <th scope="col">Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!empty($records)): ?>
                            <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                <td><?php echo e($item['name']); ?></td>
                                <td><?php echo e($item['age']); ?></td>
                                <td><?php echo e($item['gender']); ?></td>
                                <td><?php echo e($item['address']); ?></td>
                                <td><?php echo e($item['contact_no']); ?></td>
                                <td><?php echo e($item['blood_group']); ?></td>
                                <td><?php echo e($item['volume']); ?></td>

                                <?php if(Auth::user()->type == 'admin'): ?>

                                <td>
                                    <a href="/events/<?php echo e($event->id); ?>/remove-donation-record/<?php echo e($item['id']); ?>"><i
                                            class="material-icons">delete</i></a>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
        
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<div class="modal fade" id="addDonationRecordModal" tabindex="1" role="dialog"
    aria-labelledby="addDonationRecordModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/events/<?php echo e($event->id); ?>/view/add-donation-record" method="POST">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <label for="name" class="bmd-label-floating">Name</label>
                        <input name="name" required type="text" class="form-control" id="name">
                    </div>

                    <div class="form-group">
                        <label for="age" class="bmd-label-floating">Age</label>
                        <input name="age" required type="number" class="form-control" id="age">
                    </div>

                    <div class="form-group">
                        <label for="gender" class="bmd-label-floating">Gender</label>
                        <label class="radio-inline pt-3">
                            <input type="radio" name="gender" id="inlineRadio1" value="male" checked> Male
                        </label>
                        <label class="radio-inline">
                            <input type="radio" name="gender" id="inlineRadio2" value="female"> Female
                        </label>
                    </div>

                    <div class="form-group">
                        <label for="address" class="bmd-label-floating">Address</label>
                        <input name="address" required type="text" class="form-control" id="address">
                    </div>

                    <div class="form-group">
                        <label for="contact_no" class="bmd-label-floating">Contact No</label>
                        <input name="contact_no" required type="text" class="form-control" id="contact_no">
                    </div>

                    <div class="form-group">
                        <label for="blood_group" class="bmd-label-floating">Blood Group</label>
                        <input name="blood_group" required type="text" class="form-control" id="blood_group">
                    </div>

                    <div class="form-group">
                        <label for="volume" class="bmd-label-floating">Volume (ml)</label>
                        <input name="volume" required type="number" class="form-control" id="volume">
                    </div>

                    <button type="submit" class="btn btn-primary btn-raised mt-4">Add Record</button>
                </form>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\WTN\FINAL_YEAR_PROJECTS\BloodBankManagementSystem\BloodBankManagementSystem\resources\views/dashboard/events/single.blade.php ENDPATH**/ ?>