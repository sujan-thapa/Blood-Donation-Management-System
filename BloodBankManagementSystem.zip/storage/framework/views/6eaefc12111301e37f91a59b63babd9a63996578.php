<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb ">
    <ol class="breadcrumb bg-transparent">
        <li class="breadcrumb-item "><a href="/" class="text-dark">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Events</li>
    </ol>
</nav>


<?php if(Auth::user()->type == 'admin'): ?>

<a href="/events/add" class="btn btn-dark active">Add Event</a>
<?php endif; ?>



<div class="card mt-3 table-responsive">

    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Description</th>
                <th scope="col">Date & Time</th>
                <th scope="col">Location</th>
                <th scope="col">Created At</th>
                <th scope="col">Total Donation</th>
                <th scope="col">Total Volume (ml)</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if(!empty($datas)): ?>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                <td><?php echo e($item['title']); ?></td>
                <td><?php echo e(Str::limit($item['desc'], 40)); ?></td>
                <td><?php echo e($item['date_time']); ?></td>
                <td><?php echo e($item['location']); ?></td>
                <td><?php echo e(date( "m/d/Y", strtotime($item['created_at']))); ?></td>
                <td><?php echo e($item['total_donation']); ?></td>
                <td><?php echo e($item['total_volume']); ?></td>
                <td>
                    <a href="/events/<?php echo e($item['id']); ?>/view"><i class="material-icons">remove_red_eye</i></a>

                    <?php if(Auth::user()->type == 'admin'): ?>

                    <a href="/events/<?php echo e($item['id']); ?>/edit"><i class="material-icons text-dark">edit</i></a>
                    <a href="/events/<?php echo e($item['id']); ?>/remove"><i class="material-icons text-danger">delete</i></a>
                    <?php endif; ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\WTN\FINAL_YEAR_PROJECTS\BloodBankManagementSystem\BloodBankManagementSystem\resources\views/dashboard/events/index.blade.php ENDPATH**/ ?>