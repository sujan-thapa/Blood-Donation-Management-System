<?php $__env->startSection('content'); ?>

<div class="mt-3">
    <div class="row">
        <div class="col-12 col-md-4">
            <div class="card">
                <div class="card-body text-center p-3">
                    <h5 class="card-title">
                        Events Organized
                    </h5>
                    <div class="text-center h1 font-weight-bold">
                        <?php echo e($total_events); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-4">
            <div class="card">
                <div class="card-body text-center p-3">
                    <h5 class="card-title ">
                        Total Donations
                    </h5>
                    <div class="text-center h1 font-weight-bold">
                        <?php echo e($total_donations); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-4">
            <div class="card">
                <div class="card-body text-center p-3">
                    <h5 class="card-title">
                        Total Blood Volume (ml)
                    </h5>
                    <div class="text-center h1 font-weight-bold">
                        <?php echo e($total_volume); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card mt-5">

    <div class="card-body">
        <h5 class="card-title">Blood In Stock</h5>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Blood Group</th>
                    <th scope="col">Blood Volume (ml)</th>
                </tr>
            </thead>
            <tbody>
                <?php if(!empty($blood_quantities)): ?>
                    <?php $__currentLoopData = $blood_quantities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->index + 1); ?></th>
                            <td><?php echo e($item['group']); ?></td>
                            <td><?php echo e($item['volume']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            </tbody>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\WTN\FINAL_YEAR_PROJECTS\BloodBankManagementSystem\BloodBankManagementSystem\resources\views/dashboard/home/index.blade.php ENDPATH**/ ?>