<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-12 col-md-8">
            <div class="card mt-3 mb-5">
                <div class="card-body">
                    <h5 class="card-title text-center">Profile</h5>
                    <?php if($profile->image == '-'): ?>
                    <img src="<?php echo e(asset('/images/profile_placeholder.png')); ?>" class="img-fluid d-block m-auto"
                        style="max-height: 150px;">
                    <?php else: ?>

                    <img src="<?php echo e(asset('/images/profile/'.$profile->image)); ?>" class="img-fluid d-block m-auto"
                        style="max-height: 150px;">
                    <?php endif; ?>
                    <ul class="list-group">
                        <a class="list-group-item">
                            <div class="bmd-list-group-col">
                                <p class="list-group-item-heading">Name</p>
                                <p class="list-group-item-text"><?php echo e($profile->name); ?></p>
                            </div>
                        </a>
                        <a class="list-group-item">
                            <div class="bmd-list-group-col">
                                <p class="list-group-item-heading">Gender</p>
                                <p class="list-group-item-text"><?php echo e($profile->gender); ?></p>
                            </div>
                        </a>
                        <a class="list-group-item">
                            <div class="bmd-list-group-col">
                                <p class="list-group-item-heading">Age</p>
                                <p class="list-group-item-text"><?php echo e($profile->age); ?></p>
                            </div>
                        </a>
                        <a class="list-group-item">
                            <div class="bmd-list-group-col">
                                <p class="list-group-item-heading">Blood Group</p>
                                <p class="list-group-item-text"><?php echo e($profile->blood_group); ?></p>
                            </div>
                        </a>
                        <a class="list-group-item">
                            <div class="bmd-list-group-col">
                                <p class="list-group-item-heading">Email</p>
                                <p class="list-group-item-text"><?php echo e($user->email); ?></p>
                            </div>
                        </a>
                        <a class="list-group-item">
                            <div class="bmd-list-group-col">
                                <p class="list-group-item-heading">Contact</p>
                                <p class="list-group-item-text"><?php echo e($profile->contact); ?></p>
                            </div>
                        </a>
                        <a class="list-group-item">
                            <div class="bmd-list-group-col">
                                <p class="list-group-item-heading">Address</p>
                                <p class="list-group-item-text"><?php echo e($profile->address); ?></p>
                            </div>
                        </a>
                    </ul>
                    <div class="text-center">
                        <button type="button" class="btn btn-primary active" data-toggle="modal"
                            data-target="#editProfileModal">
                            Edit Profile
                        </button>

                    </div>
                </div>
            </div>

        </div>
    </div>

    
    <div class="">


        <div class="card mt-3 mb-5">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h5 class="card-title ">Joined Events</h5>
                </div>
                <div class="  mt-3 table-responsive">

                 <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Title</th>
                            <th scope="col">Description</th>
                            <th scope="col">Date & Time</th>
                            <th scope="col">Location</th>
                            <th scope="col">Donated Volume (ml)</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($joined_events)): ?>
                        <?php $__currentLoopData = $joined_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->index + 1); ?></th>
                            <td><?php echo e($item['title']); ?></td>
                            <td><?php echo e(Str::limit($item['desc'], 40)); ?></td>
                            <td><?php echo e($item['date_time']); ?></td>
                            <td><?php echo e($item['location']); ?></td>
                            <td><?php echo e($item['volume']); ?></td>
                            <td>
                                <a href="/public-events/<?php echo e($item['event_id']); ?>"><i class="material-icons">remove_red_eye</i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>

                </div>
            </div>
        </div>


    </div>
    
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>
<div class="modal fade" id="editProfileModal" tabindex="-1" role="dialog" aria-labelledby="editProfileModallLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editProfileModalLabel">
                    Edit Profile
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form action="/public-profile/edit" method="POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="name" class="bmd-label-floating">Name</label>
                        <?php if($profile->name == '-'): ?>

                        <input name="name" required type="text" class="form-control" id="name">
                        <?php else: ?>
                        <input name="name" required type="text" class="form-control" id="name"
                            value="<?php echo e($profile->name); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="age" class="bmd-label-floating">Age</label>
                        <input name="age" required type="number" class="form-control" id="age"
                            value="<?php echo e($profile->age); ?>">
                    </div>
                    <div class="form-field pt-2">
                        <label for="blood_group" class="bmd-label-floating">Blood Group</label>
                        <select name="blood_group" class="form-control" id="blood_group">
                            <option value="A+" checked> A+</option>
                            <option value="A-"> A-</option>
                            <option value="B+"> B+</option>
                            <option value="B-"> B-</option>
                            <option value="AB+"> AB+</option>
                            <option value="AB-"> AB-</option>
                            <option value="O+"> O+</option>
                            <option value="O-"> O-</option>
                        </select>
                    </div>

                    <div class=" ">
                        <div>
                            <label class="bmd-label-floating">Gender</label>
                        </div>
                        <label class="radio-inline">
                            <?php if($profile->gender == 'male'): ?>
                            <input type="radio" name="gender" id="inlineRadio1" value="male" checked> Male
                            <?php else: ?>
                            <input type="radio" name="gender" id="inlineRadio1" value="male"> Male
                            <?php endif; ?>
                        </label>
                        <label class="radio-inline">
                            <?php if($profile->gender == 'female'): ?>
                            <input type="radio" name="gender" id="inlineRadio1" value="female" checked> Female
                            <?php else: ?>
                            <input type="radio" name="gender" id="inlineRadio1" value="female"> Female
                            <?php endif; ?>
                        </label>
                    </div>
                    <div class="form-group">
                        <label for="Contact" class="bmd-label-floating">Contact</label>
                        <?php if($profile->contact == '-'): ?>

                        <input name="contact" required type="text" class="form-control" id="Contact">
                        <?php else: ?>
                        <input name="contact" required type="text" class="form-control" id="Contact"
                            value="<?php echo e($profile->contact); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="Address" class="bmd-label-floating">Address</label>
                        <?php if($profile->address == '-'): ?>

                        <input name="address" required type="text" class="form-control" id="Address">
                        <?php else: ?>
                        <input name="address" required type="text" class="form-control" id="Address"
                            value="<?php echo e($profile->address); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="form-group pt-2">
                        <label for="Image" class="bmd-label-floating">Profile Image File</label>
                        <input name="image" type="file" class="form-control-file" id="Image">
                    </div>
                    <button type="submit" class="btn btn-primary btn-raised mt-4">Submit</button>
                </form>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\WTN\FINAL_YEAR_PROJECTS\BloodBankManagementSystem\BloodBankManagementSystem\resources\views/site/profile.blade.php ENDPATH**/ ?>