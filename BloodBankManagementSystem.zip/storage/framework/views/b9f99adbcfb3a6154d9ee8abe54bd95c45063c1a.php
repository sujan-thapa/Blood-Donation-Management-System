<?php $__env->startSection('content'); ?>





<div class="container-fluid events-container">

    <div class=" ">

        <div class="h2 title text-center pt-3 pb-3">
            <span>Events</span>
        </div>
        <div class="row">
            <?php if(!empty($events)): ?>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-md-4 mt-1">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title font-weight-bold"><?php echo e($item->title); ?></h5>
                        <p class="card-text">
                            <?php echo e(Str::limit($item['desc'], 100)); ?>

                        </p>
                        <span>
                            <?php echo e($item->date_time); ?>

                        </span>
                        <br>
                        <span>
                            <?php echo e($item->location); ?>

                        </span>
                        <div class="text-center mt-2">
                            <a href="/public-events/<?php echo e($item->id); ?>"
                                class="btn  px-5 text-capitalize btn-more_info">More</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>


</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\WTN\FINAL_YEAR_PROJECTS\BloodBankManagementSystem\BloodBankManagementSystem\resources\views/site/events.blade.php ENDPATH**/ ?>