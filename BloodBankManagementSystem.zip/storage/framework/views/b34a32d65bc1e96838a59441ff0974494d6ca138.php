<?php $__env->startSection('content'); ?>


<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-12 col-md-8">
            <div class="alert alert-info mt-5">
                <h5>Your request is being processed.</h5>
            </div>
        </div>
    </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\WTN\FINAL_YEAR_PROJECTS\BloodBankManagementSystem\BloodBankManagementSystem\resources\views/site/request-for-blood-success.blade.php ENDPATH**/ ?>