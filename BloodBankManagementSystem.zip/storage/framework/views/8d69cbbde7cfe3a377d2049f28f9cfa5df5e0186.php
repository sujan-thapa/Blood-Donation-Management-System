<?php $__env->startSection('content'); ?>


<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-12 col-md-8">
            <div class="card mt-5">

                <div class="card-body">
                    <h5 class="card-title">Blood In Stock</h5>

                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Blood Group</th>
                                <th scope="col">Blood Volume (ml)</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!empty($blood_quantities)): ?>
                            <?php $__currentLoopData = $blood_quantities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                <td><?php echo e($item['group']); ?></td>
                                <td><?php echo e($item['volume']); ?></td>
                                <td>

                                    <button class="btn btn-dark active" data-toggle="modal"
                                        data-target="#<?php echo e($item['group']); ?>Modal">Request For
                                        Blood</button>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<?php if(!empty($blood_quantities)): ?>
<?php $__currentLoopData = $blood_quantities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="modal fade" id="<?php echo e($item['group']); ?>Modal" tabindex="-1" role="dialog"
    aria-labelledby="<?php echo e($item['group']); ?>ModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="<?php echo e($item['group']); ?>ModalLabel">Request For Blood Group '<?php echo e($item['group']); ?>'
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/request-for-blood" method="POST">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <label for="blood_group" class="bmd-label-floating">Group</label>
                        <input name="blood_group" required type="text" class="form-control" id="blood_group"
                            value="<?php echo e($item['group']); ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label for="volume" class="bmd-label-floating">Volume (ml)</label>
                        <input name="volume" required type="number" class="form-control" id="volume">
                    </div>
                    <div class="form-group">
                        <label for="reason" class="bmd-label-floating">Reason </label>
                        <textarea name="reason" required type="text" class="form-control" id="reason"></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary btn-raised mt-4">Send Request</button>
                </form>

            </div>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\WTN\FINAL_YEAR_PROJECTS\BloodBankManagementSystem\BloodBankManagementSystem\resources\views/site/request-for-blood.blade.php ENDPATH**/ ?>