<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb ">
    <ol class="breadcrumb bg-transparent">
        <li class="breadcrumb-item "><a href="/dashboard" class="text-dark">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Users</li>
    </ol>
</nav>


<?php if(Auth::user()->type == 'admin'): ?>

<a href="/events/add" class="btn btn-dark active" data-toggle="modal" data-target="#addUserModal">Add User</a>
<?php endif; ?>



<div class="card mt-3 table-responsive">

    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Type</th>
                <th scope="col">Image</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Contact</th>
                <th scope="col">Address</th>
                <th scope="col">Created At</th>
                <?php if(Auth::user()->type == 'admin'): ?>
                <th scope="col">Action</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php if(!empty($users)): ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                <td><?php echo e($item['type']); ?></td>
                <td><?php echo e($item['image']); ?></td>
                <td><?php echo e($item['name']); ?></td>
                <td><?php echo e($item['email']); ?></td>
                <td><?php echo e($item['contact']); ?></td>
                <td><?php echo e($item['address']); ?></td>
                <td><?php echo e(date( "m/d/Y", strtotime($item['created_at']))); ?></td>
                <td>
                    <?php if(Auth::user()->type == 'admin'): ?>
                    <a href="/users/<?php echo e($item['user_id']); ?>/edit"><i class="material-icons text-dark">edit</i></a>
                    <a href="/users/<?php echo e($item['user_id']); ?>/remove"><i class="material-icons text-danger">delete</i></a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>
<div class="modal fade" id="addUserModal" tabindex="-1" role="dialog" aria-labelledby="addUserModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addUserModalLabel">Add New User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">


                
                <form action="/users/add" method="POST">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <label for="name" class="bmd-label-floating">Name</label>
                        <input name="name" required type="text" class="form-control" id="name">
                    </div>
                    <div class="form-group">
                        <label for="contact" class="bmd-label-floating">Contact</label>
                        <input name="contact" required type="text" class="form-control" id="contact">
                    </div>
                    <div class="form-group">
                        <label for="address" class="bmd-label-floating">Address</label>
                        <input name="address" required type="text" class="form-control" id="address">
                    </div>

                    <div>
                        <label class="bmd-label-floating">Type</label>
                        <div>
                            <label class="radio-inline">
                                <input type="radio" name="type" id="admin" value="admin"> Admin
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="type" id="staff" value="staff"> Staff
                            </label>
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="date_time" class="bmd-label-floating">Email</label>
                        <input name="email" required type="text" class="form-control" id="date_time">
                    </div>
                    <div class="form-group">
                        <label for="Password" class="bmd-label-floating">Password</label>
                        <input name="password" required type="password" class="form-control" id="Password">
                    </div>


                    <button type="submit" class="btn btn-primary btn-raised mt-4">Add User</button>
                </form>
                


            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\WTN\FINAL_YEAR_PROJECTS\BloodBankManagementSystem\BloodBankManagementSystem\resources\views/dashboard/users/index.blade.php ENDPATH**/ ?>