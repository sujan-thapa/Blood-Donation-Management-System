<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb ">
    <ol class="breadcrumb bg-transparent">
        <li class="breadcrumb-item "><a href="/dashboard" class="text-dark">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Blood Requests</li>
    </ol>
</nav>



<div class="card mt-3">
    <div class="card-body">

        <h5 class="card-title">Blood Requests Lists</h5>
        <div>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Requested At</th>
                        <th scope="col">Blood Group</th>
                        <th scope="col">Volume (ml)</th>
                        <th scope="col">Name</th>
                        <th scope="col">Gender</th>
                        <th scope="col">Age</th>
                        <th scope="col">Address</th>
                        <th scope="col">Contact</th>
                        <th scope="col">Email</th>
                        <?php if(Auth::user()->type == 'admin'): ?>

                        <th scope="col">Action</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($blood_requests)): ?>
                    <?php $__currentLoopData = $blood_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->index + 1); ?></th>

                        <td><?php echo e(date( "m/d/Y", strtotime($item['created_at']))); ?></td>
                        <td><?php echo e($item['blood_group']); ?></td>
                        <td><?php echo e($item['volume']); ?></td>
                        <td><?php echo e($item['name']); ?></td>
                        <td><?php echo e($item['gender']); ?></td>
                        <td><?php echo e($item['age']); ?></td>
                        <td><?php echo e($item['address']); ?></td>
                        <td><?php echo e($item['contact']); ?></td>
                        <td><?php echo e($item['email']); ?></td>
                        <?php if(Auth::user()->type == 'admin'): ?>

                        <td>
                            <a href="/blood-requests/<?php echo e($item['blood_request_id']); ?>/remove"><i
                                    class="material-icons text-danger">delete</i></a>
                        </td>
                        <?php endif; ?>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\WTN\FINAL_YEAR_PROJECTS\BloodBankManagementSystem\BloodBankManagementSystem\resources\views/dashboard/bloodrequests/index.blade.php ENDPATH**/ ?>