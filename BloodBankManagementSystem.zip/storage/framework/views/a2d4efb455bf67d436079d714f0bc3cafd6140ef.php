<?php $__env->startSection('content'); ?>


<div class="container-fluid">


  <div class="row justify-content-center">
    <div class="col-12 col-md-8">
        <div class="card mt-3 mb-5">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($event->title); ?></h5>
                <p class="cart-text">
                    <?php echo e($event->desc); ?>

                </p>
                <p>
                    <span>
                        Date & Time : <?php echo e($event->date_time); ?>

                    </span>
                    <br>
                    <span>
                        Location : <?php echo e($event->location); ?>

                    </span>
                </p>

            </div>
        </div>
    </div>
</div>



<div class="card mt-3 mb-5">
    <div class="card-body">
        <div class="d-flex justify-content-between">
            <h5 class="card-title ">Donation Record</h5>
        </div>

        <div class="  mt-3 table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Age</th>
                        <th scope="col">Gender</th>
                        <th scope="col">Blood Group</th>
                        <th scope="col">Volume (ml)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($records)): ?>
                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->index + 1); ?></th>
                        <td><?php echo e($item['name']); ?></td>
                        <td><?php echo e($item['age']); ?></td>
                        <td><?php echo e($item['gender']); ?></td>
                        <td><?php echo e($item['blood_group']); ?></td>
                        <td><?php echo e($item['volume']); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>
    </div>
</div>


</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\WTN\FINAL_YEAR_PROJECTS\BloodBankManagementSystem\BloodBankManagementSystem\resources\views/site/single-event.blade.php ENDPATH**/ ?>