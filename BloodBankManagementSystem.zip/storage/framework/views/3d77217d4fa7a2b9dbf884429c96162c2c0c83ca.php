<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb ">
    <ol class="breadcrumb bg-transparent">
        <li class="breadcrumb-item "><a href="/dashboard" class="text-dark">Home</a></li>
        <li class="breadcrumb-item "><a href="/users" class="text-dark">Users</a></li>
        <li class="breadcrumb-item active" aria-current="page">Edit</li>
    </ol>
</nav>


<div class="row justify-content-center">
    <div class="col-12 col-md-5">
        <div class="card mt-3">

            <div class="card-body">

                <h5 class="card-title">
                    Edit User Info
                </h5>

                
                <form action="/users/<?php echo e($user->id); ?>/edit" method="POST">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <label for="name" class="bmd-label-floating">Name</label>
                        <input name="name" required type="text" class="form-control" id="name"
                            value="<?php echo e($admininfo->name); ?>">
                    </div>
                    <div class="form-group">
                        <label for="contact" class="bmd-label-floating">Contact</label>
                        <input name="contact" required type="text" class="form-control" id="contact"
                            value="<?php echo e($admininfo->contact); ?>">
                    </div>
                    <div class="form-group">
                        <label for="address" class="bmd-label-floating">Address</label>
                        <input name="address" required type="text" class="form-control" id="address"
                            value="<?php echo e($admininfo->address); ?>">
                    </div>

                    <div>
                        <label class="bmd-label-floating">Type</label>
                        <div>
                            <?php if($user->type == 'admin'): ?>

                            <label class="radio-inline">
                                <input required type="radio" name="type" id="admin" value="admin" checked> Admin
                            </label>

                            <?php else: ?>
                            <label class="radio-inline">
                                <input required type="radio" name="type" id="admin" value="admin"> Admin
                            </label>
                            <?php endif; ?>

                            <?php if($user->type == 'staff'): ?>
                            <label class="radio-inline">
                                <input required type="radio" name="type" id="staff" value="staff" checked> Staff
                            </label>

                            <?php else: ?>
                            <label class="radio-inline">
                                <input required type="radio" name="type" id="staff" value="staff"> Staff
                            </label>
                            <?php endif; ?>


                        </div>
                    </div>

                    <div class="form-group">
                        <label for="Password" class="bmd-label-floating">Password</label>
                        <input name="password" type="password" class="form-control" id="Password">
                    </div>


                    <button type="submit" class="btn btn-primary btn-raised mt-4">Add User</button>
                </form>
                

            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\WTN\FINAL_YEAR_PROJECTS\BloodBankManagementSystem\BloodBankManagementSystem\resources\views/dashboard/users/edit.blade.php ENDPATH**/ ?>