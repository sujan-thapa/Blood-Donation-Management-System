@extends('site.layouts.base')



@section('content')


<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-12 col-md-8">
            <div class="alert alert-info mt-5">
                <h5>Your request is being processed.</h5>
            </div>
        </div>
    </div>


    @endsection
